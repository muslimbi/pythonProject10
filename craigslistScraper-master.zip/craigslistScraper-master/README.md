# craigslistScraper
Web scraper that grabs data from craigslist.org. It searches the listings for key words and emails the user when new matching listings appear. Details about the listing are included in the email.
