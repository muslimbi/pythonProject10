# Function
It searches for emails from employee seekers on Craigslist in the Education Section in NYC, and it saves their email in a database that you can access and email your resume to them.

It can be modified to search in any other sections too.

# Usage
`Python sele.py [search:word to search]`
